class WebSerial():
    def read(self, num_bytes):
        import js

        buffer = ""
        while len(buffer) < num_bytes:
            buffer += js.workerReadSerial()

        return buffer.encode("ascii")

    def write(self, bytes_out):
        import js
        print(bytes_out)
        js.workerWriteSerial(bytes_out.decode("ascii"))
